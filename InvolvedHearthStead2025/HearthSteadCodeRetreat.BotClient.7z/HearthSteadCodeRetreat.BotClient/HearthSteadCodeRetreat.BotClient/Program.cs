﻿using HearthSteadCodeRetreat.BotClient;

var hearthSteadHttpClient = new HearthSteadHttpClient("BotUserName", "BotSecret");

new BotClient(hearthSteadHttpClient).Run();

Console.ReadLine();
