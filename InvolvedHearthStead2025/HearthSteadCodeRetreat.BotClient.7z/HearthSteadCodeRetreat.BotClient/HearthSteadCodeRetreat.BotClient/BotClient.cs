﻿using HearthStead.Dto;
using HearthStead.Dto.Messages;
using Microsoft.AspNetCore.SignalR.Client;

namespace HearthSteadCodeRetreat.BotClient;

public class BotClient
{
    private readonly HearthSteadHttpClient _client;

    public BotClient(HearthSteadHttpClient client)
    {
        _client = client;
    }

    public async Task Run()
    {
        // Settle villager aka enroll/register
        await _client.SettleVillager();
        // Get token
        await _client.GetEndorsement();

        var connection = new HubConnectionBuilder().WithUrl($"{_client.BaseUrl}/HearthSteadHub", options => { })
            .Build();

        await connection.StartAsync();

        // New day started for HeartStead
        // What will you do today?
        connection.On("NewDay", async (HearthSteadDto hearthSteadDto) => { });

        // A villager posted a message on the message board
        connection.On("MessagePosted", async (MessageDto message) => { });
    }
}