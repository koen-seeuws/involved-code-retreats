﻿using System.Net.Http.Headers;
using System.Text;
using System.Text.Json;
using HearthStead.Dto.Villagers;

namespace HearthSteadCodeRetreat.BotClient;

public class HearthSteadHttpClient(string villagerName, string villagerSecret)
{
    public readonly string BaseUrl = "https://app-hearthstead.azurewebsites.net/";

    private string? _villagerToken;

    public async Task SettleVillager()
    {
        var villagerCharter = new VillagerCharterDto()
        {
            VillagerName = villagerName,
            VillagerSecret = villagerSecret
        };
        var responseRegister = await GetClient()
            .PostAsync(
                "api/villager/settle", new
                    StringContent(JsonSerializer.Serialize(villagerCharter), Encoding.UTF8, "application/json"),
                CancellationToken.None);
    }

    public async Task GetEndorsement()
    {
        var villagerCharter = new VillagerCharterDto()
        {
            VillagerName = villagerName,
            VillagerSecret = villagerSecret
        };
        var response = await GetClient().PostAsync("api/villager/endorse",
            new StringContent(JsonSerializer.Serialize(villagerCharter), Encoding.UTF8, "application/json"),
            CancellationToken.None);
        
        _villagerToken = await response.Content.ReadAsStringAsync();
    }

    public string? GetToken()
    {
        return _villagerToken;
    }

    public HttpClient GetClient()
    {
        var client = new HttpClient();
        client.BaseAddress = new Uri(BaseUrl);

        if (!string.IsNullOrEmpty(_villagerToken))
        {
            client.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Bearer", _villagerToken);
        }
        
        return client;
    }

    public string GetVillagerName()
    {
        return villagerName;
    }
}