﻿namespace HearthStead.Dto.ActionLogs;

public class ActionLogDto
{
    public string VillagerName { get; set; }
    public string BuildingName { get; set; }
    public string ActionName { get; set; }
    public string FailedReason { get; set; }
}