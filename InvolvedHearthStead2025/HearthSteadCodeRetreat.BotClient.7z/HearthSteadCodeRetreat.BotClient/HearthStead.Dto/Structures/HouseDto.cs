﻿namespace HearthStead.Dto.Structures;

public class HouseDto : StructureDto;