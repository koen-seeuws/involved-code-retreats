﻿namespace HearthStead.Dto.Structures;

public class SawMillDto : StructureDto
{
    
}