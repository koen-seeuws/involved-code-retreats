﻿namespace HearthStead.Dto.Structures;

public class CharcoalKilnDto : StructureDto
{
    
}