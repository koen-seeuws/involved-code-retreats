﻿namespace HearthStead.Dto.Structures;

public class OreMineDto : StructureDto
{
    
}