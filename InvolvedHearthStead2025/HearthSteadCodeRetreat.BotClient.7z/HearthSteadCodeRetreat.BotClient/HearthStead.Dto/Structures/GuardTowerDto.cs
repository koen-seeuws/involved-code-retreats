﻿namespace HearthStead.Dto.Structures;

public class GuardTowerDto : StructureDto
{
    
}