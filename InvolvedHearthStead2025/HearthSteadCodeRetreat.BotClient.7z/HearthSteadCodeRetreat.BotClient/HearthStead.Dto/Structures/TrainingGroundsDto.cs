﻿namespace HearthStead.Dto.Structures;

public class TrainingGroundsDto : StructureDto
{
    
}