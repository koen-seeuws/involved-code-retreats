﻿namespace HearthStead.Dto.Structures;

public class FarmDto : StructureDto
{
    public List<FarmFieldDto> FarmFields { get; set; }
}
