﻿namespace HearthStead.Dto.Structures;

public class StoneMineDto : StructureDto
{
    
}