﻿using HearthStead.Dto.Enums;

namespace HearthStead.Dto.Structures;

public class FarmFieldDto
{
    public string FieldName { get; set; }
    public FarmStatusDto Status { get; set; }
}