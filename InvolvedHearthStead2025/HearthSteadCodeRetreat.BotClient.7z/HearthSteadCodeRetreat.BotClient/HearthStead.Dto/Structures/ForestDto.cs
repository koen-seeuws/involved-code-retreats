﻿namespace HearthStead.Dto.Structures;

public class ForestDto : StructureDto
{
    
}