﻿namespace HearthStead.Dto.Structures;

public class WorkshopDto : StructureDto
{
    
}