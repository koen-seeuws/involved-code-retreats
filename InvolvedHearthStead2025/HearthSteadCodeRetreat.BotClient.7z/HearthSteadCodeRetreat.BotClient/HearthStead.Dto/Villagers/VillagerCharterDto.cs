﻿namespace HearthStead.Dto.Villagers;

public class VillagerCharterDto
{
    public string VillagerName { get; set; }

    public string VillagerSecret { get; set; }
}