﻿namespace HearthStead.Dto.Enums;

public enum FarmStatusDto
{
    Fallow,
    Plowed,
    Growing,
    Harvestable
}