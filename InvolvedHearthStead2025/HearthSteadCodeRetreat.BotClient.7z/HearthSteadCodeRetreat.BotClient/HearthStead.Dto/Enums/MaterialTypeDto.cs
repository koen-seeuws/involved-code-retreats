﻿namespace HearthStead.Dto.Enums;

public enum MaterialTypeDto
{
    Wood,
    Planks,
    Ore,
    Ingots,
    Food,
    Charcoal,
    Stone
}