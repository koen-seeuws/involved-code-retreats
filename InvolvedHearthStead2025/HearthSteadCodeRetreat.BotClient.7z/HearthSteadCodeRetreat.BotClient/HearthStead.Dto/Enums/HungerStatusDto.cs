﻿namespace HearthStead.Dto.Enums;

public enum HungerStatusDto
{
    Starved,
    Starving,
    Hungry,
    Fed,
    WellFed
}