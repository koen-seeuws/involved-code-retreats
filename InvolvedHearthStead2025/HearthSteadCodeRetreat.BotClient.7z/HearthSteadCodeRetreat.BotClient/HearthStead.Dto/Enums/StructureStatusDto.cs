﻿namespace HearthStead.Dto.Enums;

public enum StructureStatusDto
{
    Dilapidated,
    RunDown,
    Fair,
    WellMaintained,
    Pristine
}