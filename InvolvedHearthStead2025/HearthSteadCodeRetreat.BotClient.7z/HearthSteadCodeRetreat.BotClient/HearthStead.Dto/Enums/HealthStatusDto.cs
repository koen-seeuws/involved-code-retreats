﻿namespace HearthStead.Dto.Enums;

public enum HealthStatusDto
{
    Moribund,
    Critical,
    Stable,
    Healthy,
    Exemplary
}