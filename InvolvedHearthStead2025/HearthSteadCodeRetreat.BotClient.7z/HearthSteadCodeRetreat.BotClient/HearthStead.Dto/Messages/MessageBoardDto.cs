﻿namespace HearthStead.Dto.Messages;

public class MessageBoardDto
{
    public List<MessageDto> Messages { get; set; }
}