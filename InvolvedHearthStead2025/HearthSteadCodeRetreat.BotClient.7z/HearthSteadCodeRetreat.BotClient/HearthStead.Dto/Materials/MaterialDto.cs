﻿using HearthStead.Dto.Enums;

namespace HearthStead.Dto.Materials;

public class MaterialDto
{
    public MaterialTypeDto MaterialType { get; set; }
    public int MaterialQuantity { get; set; } 
}