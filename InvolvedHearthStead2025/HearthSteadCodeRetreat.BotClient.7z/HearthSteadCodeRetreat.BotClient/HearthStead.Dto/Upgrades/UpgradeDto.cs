﻿using HearthStead.Dto.Materials;

namespace HearthStead.Dto.Upgrades;

public class UpgradeDto
{
    public string Name { get; set; } 
    public string Description { get; set; } 
    public List<MaterialDto> UpgradeCost { get; set; } 
    public bool Unlocked { get; set; } 
}